package listInterfaceAndClasses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


public class ArrayListExample {

	public static void main(String[] args) {
		
		//Maintains insertion order, Can contain duplicate elements, sort through List,can have null values
		ArrayList<String> al = new ArrayList<String>();
		al.add("Jan");
		al.add("Feb");
		al.add("Mar");
		al.add(null);
		//Normal iteration - for loop
		for(int i=0;i<al.size();i++) {
			System.out.println(al.get(i));
		}
		System.out.println("************");
		
		//Iteration - for each loop
		for(String s:al) {
			System.out.println(s);
		}
		System.out.println("************");
		
		//Iterating thorugh iterator
		Iterator it = al.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("************");
		
		//Changing the index values using set method
		al.set(3, "Apr");
		for(int i=0;i<al.size();i++) {
			System.out.println(al.get(i));
		}
		System.out.println("************");
		
		
		List<String> li = new LinkedList<String>();
		li.add("Jan");
		li.add("Feb");
		li.add("Mar");
		li.add("Apr");
		
		System.out.println(li.get(2));
		System.out.println(li.set(3, "May"));
	
		Collections.sort(li);
		for(String s:li) {
			System.out.println(s);
		}
		System.out.println("************");
		
		Employee e = new Employee("Nandhini","TTL",28,50000);
		Employee e1 = new Employee("Vaish","TA",29,40000);
		Employee e2 = new Employee("Roh","MANAGER",28,60000);
		Employee e3 = new Employee("Thenu","TTL",30,70000);
		
		ArrayList<Employee> emp = new ArrayList<Employee>();
		emp.add(e);
		emp.add(e1);
		emp.add(e2);
		emp.add(e3);
		
		Iterator it1 = emp.iterator();
		while(it1.hasNext()) {
			Employee em =(Employee)it1.next(); 
			System.out.println(em.name+" "+em.jd+" "+em.age+" "+em.ctc);
		}
		
	}
	
	

}
