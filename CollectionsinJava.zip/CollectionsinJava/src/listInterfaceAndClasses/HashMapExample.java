package listInterfaceAndClasses;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
		HashMap<Integer,Employee> hm = new HashMap<>();
		
		Employee e =new Employee("Vaishu","TL",29,30000);
		Employee e1 =new Employee("Nandhu","TL",30,60000);
		Employee e2 =new Employee("Nithi","TL",31,40000);
		
		hm.put(1001, e);
		hm.put(1002, e1);
		hm.put(1003, e2);
		
		for(Map.Entry<Integer,Employee> m :  hm.entrySet()) {
			Integer key = m.getKey();
			Employee v= m.getValue();
			System.out.println(key+" "+v.name+" "+v.jd+" "+v.age+" "+v.ctc);
		}
		
	}

}
