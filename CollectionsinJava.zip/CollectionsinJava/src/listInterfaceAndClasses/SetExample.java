package listInterfaceAndClasses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class SetExample {
	//Random order, cannot contain duplicates, can have null values, cannot sort using collections.sort()

	public static void main(String[] args) {
		HashSet<String> al = new HashSet<String>();
		al.add("Jan");
		al.add("Feb");
		al.add("Mar");
		al.add(null);

		System.out.println("Set1:" + al);
		
		HashSet<String> hs=new HashSet<String>();
		hs.add("May");
		hs.add("Jun");
		hs.add("Jul");
		hs.addAll(al);
		System.out.println("Set2:" +hs);
		System.out.println("******************");
		hs.remove("Mar");
		System.out.println("Removed Mar: " + hs);
		
		//RemoveAll - Removes a collection
		hs.removeAll(al);
		System.out.println("Removed Set1 from Set2: " + hs);
		System.out.println("******************");
		
		//Sort
		List<String> l = new ArrayList<String>();

		l.addAll(hs);
		Collections.sort(l);
		l.forEach(System.out::println);
		System.out.println("sorted set by adding it to list " + l);
		

	}

}
