package listInterfaceAndClasses;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapExample {

	public static void main(String[] args) {

		Map<Integer,String> m= new HashMap<Integer,String>();
		
		HashMap<Integer,String> m1 = new HashMap<Integer,String>();
		LinkedHashMap<Integer,String> m2 = new LinkedHashMap<Integer,String>();
			
		HashMap<String,String> map1 = new HashMap<String,String>();
		////if we have duplicate key, then the existing value wil be replaced with new value(i.e duplicate)
		m.put(1, "Anitha");
		m.put(2, null);
		m.put(3, "Vaish");
		m.put(1, "Nand");
		m.put(null, "Nand");
		for(Map.Entry map :m.entrySet()) {
			System.out.println(map.getKey()+ " "+map.getValue());
		}
		
		System.out.println(m);
		System.out.println("*****************");
		//TreeMap -> 'Null' key NOT allowed but 'null' value allowed
		TreeMap<Integer,String> m3 = new TreeMap<Integer,String>();
		m3.put(1, "Anitha");
		m3.put(2, null);
		m3.put(3, "Vaish");
		m3.put(1, "Nand");
		m3.put(null, "Nand");
		for(Map.Entry map :m3.entrySet()) {
			System.out.println(map.getKey()+ " "+map.getValue());
		}
		
		//System.out.println(m);
		
		
		
		
	}

}
