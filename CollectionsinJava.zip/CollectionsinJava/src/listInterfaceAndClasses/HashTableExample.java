package listInterfaceAndClasses;

import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

public class HashTableExample {
   public static void main(String[] args) {
	   //Order of insertion follows descending order of keys
	   Hashtable<Integer,String> ht = new Hashtable<>();
		   ht.put(1, "nandhu");
		   ht.put(2, "vaish");
		   ht.put(0, "Hari");
//		   for(Map.Entry<Integer,String> m : ht.entrySet()) {
//			   System.out.println(m.getKey() +" "+m.getValue());
//		   }
		
		Hashtable<Integer,Employee> h = new Hashtable<>() ;
		Employee e =new Employee("Vaishu","TL",29,30000);
		Employee e1 =new Employee("Nandhu","TL",30,60000);
		Employee e2 =new Employee("Nithi","TL",31,40000);
		
		h.put(1007, e);
		h.put(1004, e1);
		h.put(1005, e2);
		
		for(Map.Entry<Integer,Employee> m : h.entrySet()) {
			int i = m.getKey();
			Employee v = m.getValue();
			System.out.println(i + " " + v.name + " " + v.age+ " " + v.jd + " " + v.ctc);
		}
		
			
	   
   }
}
