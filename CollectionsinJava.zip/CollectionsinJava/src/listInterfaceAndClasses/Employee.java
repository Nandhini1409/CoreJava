package listInterfaceAndClasses;

public class Employee {
	
	String name;
	String jd;
	int age;
	int ctc;
	
	
	public Employee(String name,String jd,int age,int ctc) {
		this.name = name;
		this.jd = jd;
		this.age = age;
		this.ctc = ctc;
	}
	
}
