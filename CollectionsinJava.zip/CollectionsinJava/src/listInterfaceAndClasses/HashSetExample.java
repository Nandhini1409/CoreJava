package listInterfaceAndClasses;

import java.util.HashSet;

public class HashSetExample {

	public static void main(String[] args) {
		HashSet<Employee> hs = new HashSet<Employee>();
		
		Employee e =new Employee("Vaishu","TL",29,30000);
		Employee e1 =new Employee("Nandhu","TL",30,60000);
		Employee e2 =new Employee("Nithi","TL",31,40000);
		
		hs.add(e);
		hs.add(e1);
		hs.add(e2);
		
		for(Employee es: hs) {
			System.out.println(es.name+"   "+es.jd+ "    "+es.age+"    "+es.ctc);
			
		}
		
	}

}
