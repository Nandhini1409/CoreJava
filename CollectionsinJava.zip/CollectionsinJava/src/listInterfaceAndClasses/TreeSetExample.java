package listInterfaceAndClasses;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		// Maintains ascending order, cannot have 'null' values, not allows duplicate value
		
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("Vaishu");
		ts.add("Nandhini");
		ts.add("Nandhini");
		//ts.add(null);//wont allow, throws NUll pointer exception
		ts.add("Roh");
		Iterator it = ts.descendingIterator();
		while(it.hasNext()) {
			System.out.println("descending order: "+it.next());
		}
		
		
		System.out.println(ts);

	}

}
