package importantConceptsPart2;

public class T007_ThrowAThrowsKeyword {
	public static void add() {
		System.out.println("Before throw");
		//throw new RuntimeException("My runtime Exception");
		
	}

	public static void sub() throws ArithmeticException{
		
		try {
		int a = 3/0;
		System.out.println(a);
		}
		catch (ArithmeticException e) {
			
			System.out.println("Arithmetic Exception handled");
			//System.out.println(e.getMessage());
		}
		catch (Exception e1) {
			System.out.println("Second Exception");
			//System.out.println(e.getMessage());
		}
		finally {
			System.out.println("Finally block");
		}
	}
	
	public static void main(String[] args) {
		
		
		add();
		
		

	}

}
