package importantConceptsPart2;

public class T004_Constructor {
	
	
	
	int c;
	public T004_Constructor() {
		int a=10;
		int b=20;
		int c=a+b;
		this.c=c;
		
	}

	public void print() {
		System.out.println(c);
	}
	
	public static void main(String[] args) {
		T004_Constructor tc =new T004_Constructor();
		tc.print();
		
	}
	  

		
	}


