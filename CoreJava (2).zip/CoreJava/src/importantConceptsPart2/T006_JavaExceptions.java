package importantConceptsPart2;

 public class T006_JavaExceptions {
	 
   public static void main (String[] args) {
	   String s = null;
	   
	   //System.out.println(s.length());// Null pointer exception as String is null
	   
	   int a[] = new int[5];
	   int[] b = {1, 2, 3, 5};
	   //System.out.println(b[4]); // java.lang.ArrayIndexOutOfBoundsException: Index 4 out of bounds for length 4
	   System.out.println(a.length);
	   int n1 = 10;
	   int n2 = 0;
	   //int n3 = n1/n2;//java.lang.ArithmeticException: / by zero
	  // System.out.println(n3);
	   
	   
	   T004_Constructor tc1 =  new T004_Constructor();
	   tc1.c=3;
   }
}
