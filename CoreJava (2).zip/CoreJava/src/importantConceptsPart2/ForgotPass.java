package importantConceptsPart2;

public class ForgotPass  {
	//forgot password
	int age =70;
	String name ="Nandhu";
	int salary=4000;
	
	
	public void name() {
		System.out.println("name in forgot password");
	}
	
	public void verify() {
		System.out.println("verify in forgot password");
	}
	
	public static void clickSubmit() {
		System.out.println("submit in forgot password");
		
	}
	
	
	

}
