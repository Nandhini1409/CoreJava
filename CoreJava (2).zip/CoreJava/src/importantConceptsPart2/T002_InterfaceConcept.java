package importantConceptsPart2;

public class T002_InterfaceConcept implements SampleInterface2{

	public static void main(String[] args) {
		


	}
	
	public void sum() {
		
	}

	@Override
	public void addition() {
		// TODO Auto-generated method stub
		System.out.println("Print something");
	}

	

	@Override
	public void biology() {
		// TODO Auto-generated method stub
		
	}

}
