package importantConceptsPart2;

public class T003_ThisKeyword extends ForgotPass{
	int age=super.age;
	String name=super.name;
	int salary=super.salary;
	
	public T003_ThisKeyword(int age, String name, int Salary) {
		age =super.age;			//this.age=age;
		name=super.name;		//this.name=age;
		super.salary=salary;	//this.salary=salary;
	}
	
	public void display() {
		System.out.println(age+" "+name+" "+salary);
		
	}
	public static void main(String[]  args) {
		
		T003_ThisKeyword hp = new T003_ThisKeyword(30, "Vaishu", 30000);
		T003_ThisKeyword hp1 = new T003_ThisKeyword(20, "Naga", 20000);
		
		hp.display();
		hp1.display();
		
		
	}
	

}
