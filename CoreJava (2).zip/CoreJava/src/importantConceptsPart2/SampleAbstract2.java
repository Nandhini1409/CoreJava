package importantConceptsPart2;

public abstract class SampleAbstract2 {

	public abstract void lipstick();
}
