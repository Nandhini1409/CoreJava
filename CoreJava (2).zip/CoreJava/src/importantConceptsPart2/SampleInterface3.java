package importantConceptsPart2;

public interface SampleInterface3 {

}
