package importantConceptsPart2;

public interface SampleInterface2 {
	
	final int a=10;
	static int b = 20;
	static String s = "Vaishu";
	Double d  = 12.33;

	public void biology();
	public void addition();
	
}
