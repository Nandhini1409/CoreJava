package importantConceptsPart2;

public class Homepage extends ForgotPass{
	
	
	
	public static void main(String[] args) {
		Homepage hp=new Homepage();
		hp.logo();
		clickSubmit();
		
	}

	
	public void logo() {
		System.out.println("logo in home page");
		super.clickSubmit();
		
	}

	public void Homebtn() {
		System.out.println("Home button in home page");
	}
	
	public static void clickSubmit() {
		
		
		System.out.println("Submit in Home page");
	}
}
