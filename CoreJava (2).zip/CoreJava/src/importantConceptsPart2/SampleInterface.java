package importantConceptsPart2;

public interface SampleInterface extends SampleInterface2, SampleInterface3 {
	
	public void addition();
	public void subtraction();
	public void multiplication();
	void division();
	//void biology();
	
	
}
