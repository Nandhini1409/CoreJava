package importantConceptsPart2;

public abstract class SampleAbstract extends SampleAbstract2 {
	
	final int a=10;
	int b = 20;
	static String s = "Vaishu";
	Double d  = 12.33;
	
	private String v = "Vaishu";
	
	SampleAbstract(){
		
	}
	
	final String method2() {
		String s ="We";
		return s;
	}
	
	static void methodre() {
		
	};
	
	private int method3() {
		int i =90;
		return i;
	}
	//public is not mandatory and access specifier can be specified after the abstract keyword
	public abstract void noimplement();
	
	public abstract int noimplement1();
	
	public abstract void addition();
	
	public String implement(){
		String S ="Yes";
		System.out.println(S);
		return S;
	}

}
