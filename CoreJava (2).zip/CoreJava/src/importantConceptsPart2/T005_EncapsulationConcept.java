package importantConceptsPart2;

public class T005_EncapsulationConcept {

	public static void main(String[] args) {
		SampleEncapsule sa=new SampleEncapsule();
		sa.setUsername("Naga");
		System.out.println(sa.getUsername());
		
		
	}
}
