package BasicConcepts;

public class T006_SingleDimensionalArray {

	public static void main(String[] args) {
		//Single dimensional array
		int a[]=new int[5];
		a[0]=12;
		a[1]=14;
		a[2]=15;
		a[3]=21;
		a[4]=22;
		System.out.println(a[4]);
		
		int[] ab = {1,4,5,6,7,8};
		System.out.println(ab.length);
				
		double d[]=new double[2];
		d[0]=12.22;
		d[1]=23.11;
		//d[2]=34.22;
		
		boolean b[]=new boolean[2];
		b[0]=true;
		b[1]=false;
		boolean[] b1= {true, false};
		
		String s[] = new String[3];
		s[0] = "Im";
		s[1]="Learning";
		s[2]="Arrays";
		String s1[] = {"Im","learning","Java"};
		System.out.println(s1[2]);
		
		//to add multiple data types in a single array
		Object ob[]=new Object[6];
		ob[0]="Tom";
		ob[1]=2;
		ob[3]=45.55;
		ob[4]='d';
		ob[5]="01/01/1992";
		System.out.println(ob[5]);
		
	}

}
