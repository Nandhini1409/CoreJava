package BasicConcepts;

public class T001_datatypes_and_variables {
	
	static int a =100; //-->Static variable
	void method() {
		int b = 20; //local variable
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte w =78;
		int i =10; //--> One variable can hold one datatype
		char c='4';//char should be specifed in single quotes with any character inside
		double d=12.8;//double should be specified in point(.) digits
		boolean b=false;//boolean should be either true or false
		String s="Nandhini";//String should be specified in double quotes
		
		
		int data=50;//instance variable

		

	}

}
