package BasicConcepts;

public class T003_StringBufferandStringBuilder {
	public static void main(String[] args) {
		StringBuffer s=new StringBuffer("nandhini");
		StringBuilder s1=new StringBuilder("Nandhini");
		
		
		//Common methods for String Buffer and String Builder
		s.append("Nandhini");//append() method concatenates the given argument with this String.
		s.insert(1, "Vaishu");//inserts the given String with this string at the given index.
		s.replace(4, 6, "Vaishu");//replace() method replaces the given String from the specified beginIndex and endIndex.
		s.delete(0, 5);//method of the StringBuffer class deletes the String from the specified beginIndex to endIndex.
		s.reverse();//method of the StringBuilder class reverses the current String.
		System.out.println(s);
		
	}
	

}
