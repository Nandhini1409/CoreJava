package BasicConcepts;

public class T005_LoopStatements {
	
	public static void main(String[] args) {
	String s ="Nandhini";
	
	//do--while
	int ij = 0;
	do {
		System.out.println(ij);
		ij=ij+2;
	}while(ij<10);
	
	
	//while loop
	int j = 5;
	while(j<10) {
		j=j+2;
		
	
		System.out.println(j);
		//continue;
	}
	
	//for loop - iterates thorugh
	int n1=0;
	int n2 =1;
	int temp;
	for(int i=0;i<=10;i++) {
		System.out.println(n1);//0 1 1 3
		temp = n1+n2;//1 2 3
		n1=n2;//1 1 2
		n2=temp;//1 2 3	
	
	}
	
	//for each loop or enhanced for loop
	
	int[] k = {1,2,3,4,5};
	for(int m:k) {
		System.out.println(m);

	}
	
}
}
