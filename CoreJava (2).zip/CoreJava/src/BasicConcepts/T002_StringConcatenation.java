package BasicConcepts;

public class T002_StringConcatenation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 20;
		int b=10;
		//String literal
		String s=" Vaishu Naga Nandhini Chintu "; //constant pool memory one memory allocation for duplicate values
		String s2="Vaishu";//memory manage
		//new-object
		//String s1= new String("Vaishu"); //Creates seperate memory each time in Heap memory
		//String s4= new String("Vaishu");
		
		//Commonly used Methods in String Class
		String s3 = s.toUpperCase();
		String s1 = s.toLowerCase();
		String s4 = s.replaceAll("N","V");//replaces with given N with V
		char n = s.charAt(b);//charAt() method returns a character at specified index.
		s.contains(s2);//Checks for similar values in given string with original string
		s.matches(s2);//Checks if the given string is matches with original string
		s.length();//method returns length of the specified String.
		String.valueOf(a);//valueOf() method converts given type such as int, long, float, double, boolean, char and char array into String.
		s.trim();//eliminates white spaces before and after the String.
		s.replace("","");//replaces all the occurrences of old char with new char
		
		
		
		
	
	}

}
