package importantConceptsPart1;

public class T005_StaticandNonStatic {
	
	String name = "Honey";//non-static variables
	static int age = 29; //static global variables

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//T005_StaticandNonStatic.age = 30;
		age = 20;
		System.out.println(age);
		//System.out.println(T005_StaticandNonStatic.age);
		
		T005_StaticandNonStatic obj =new T005_StaticandNonStatic();
		System.out.println(obj.name);
		obj.name="Vaishu";
				System.out.println(obj.name);		
		
	}
	
	public void sum() {
		
	}
	
	public static void sendMail() {
		
		
	}
}
