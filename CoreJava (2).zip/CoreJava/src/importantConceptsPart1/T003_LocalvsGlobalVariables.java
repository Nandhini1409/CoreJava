package importantConceptsPart1;

public class T003_LocalvsGlobalVariables {
	//Global variable or class variables
	String name="TOM";
	int age=25;

	public static void main(String[] args) {
		int i=10; //local variable for main method
		
		T003_LocalvsGlobalVariables obj = new T003_LocalvsGlobalVariables();
		System.out.println(obj.name);
		System.out.println(obj.sum("Nandhini",28));
		//obj.sum("Nandhini",28);
	}
	
	public String sum(String name,int age) {
		//local variables for sum method
		this.name=name;
		this.age=age;
		
		
		
		return name;
	}

}
