package importantConceptsPart1;

public class T004_MethodOverloading {

	public static void main(String[] args) {
		T004_MethodOverloading obj =new T004_MethodOverloading();
		
		obj.sum();
		obj.sum(2);
		obj.sum(1, 2);
	}
	//we can overload main method
	public static void main(int i) {
		
	}
	//same name but diffferent paramaters
	public void sum() {
		System.out.println("No parameters");
	}
	
	public void sum(int i){
		System.out.println("int i alone");
	}
	
	public void sum(int i, int j) {
		System.out.println("two parameters");
		System.out.println(i+j);
	}
}
