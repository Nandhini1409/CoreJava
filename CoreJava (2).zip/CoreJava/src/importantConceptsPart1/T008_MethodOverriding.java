package importantConceptsPart1;

public class T008_MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
