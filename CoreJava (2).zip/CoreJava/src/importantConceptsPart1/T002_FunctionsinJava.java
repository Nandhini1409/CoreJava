package importantConceptsPart1;

public class T002_FunctionsinJava {
	//Functions and methods are same in Java
	public static void main(String[] args) {

		T002_FunctionsinJava obj = new T002_FunctionsinJava();
		obj.animal();
		obj.calc();
		System.out.println(obj.calc());
		int f = obj.calci(20, 2);
		System.out.println(f);
	}
	//we cannot have methods inside the method i.e main method.
	// non-static methods - 
	//all methods should return some value based on the return type
	public int calc() {//no input some output
		//public is access specifier int is return type, and method name.
		int a =20;
		int b =10;
		int c =a+b;
		//System.out.println(a);
		return c;
	}
	
	public String name() {//no input some output
		String s="Nandhini";
		return s;
	}
	
	public void animal() {//does not return anything
		int a =1;
		
	}
	
	public int calci(int a,int b) {
		 System.out.println("division method");
		int d = a/b;
		return d;
		
	}
}
