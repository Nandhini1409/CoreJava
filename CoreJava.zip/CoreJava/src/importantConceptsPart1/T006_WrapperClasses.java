package importantConceptsPart1;

public class T006_WrapperClasses {

	public static void main(String[] args) {
	
		String x ="100";
		//i want the output as 120, but here the output is 10020 since it is string.
		System.out.println(x+20);
		//Converting the data type from String to Int
		int i = Integer.parseInt(x);
		System.out.println(i+20);
		
		//String to double
		String y ="12.33";
		double j = Double.parseDouble(y);
		System.out.println(j+10);
		
		//String to Character -- No parsing from string to Character
		String z ="l";
		
		
		//String to Boolean
		String u = "true";
		System.out.println(u.charAt(2));
		boolean b = Boolean.parseBoolean(u);
		System.out.println(b);
		
		//int to String conversion
		int c = 78;
		String s = String.valueOf(c);
		System.out.println(c+10);
		System.out.println(s+10);
		
		//Non-conversion cases
		String f ="100A";
		//Integer.parseInt(f); //Error will occur since it has A
		
		//converting int to Integer - Autoboxing Converting primitive to wrapper class
		int n = 890;
		Integer m = Integer.valueOf(n);
		//Integer m1 = n;
		System.out.println(n);
		//System.out.println(m1);
		
		//Converting integer to int - Unboxing converting wrapper class to primitive.
		Integer a=3;    
		int k=a.intValue();//converting Integer to int explicitly  
		int l=a;
		String e = a.toString();//Wrapper class to String
		System.out.println(e+10);
		String ty = String.valueOf(a);//Wrapper class to String
		System.out.println(ty+10);
		
		
		
	}

}
