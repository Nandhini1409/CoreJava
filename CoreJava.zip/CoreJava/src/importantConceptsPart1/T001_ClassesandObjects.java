package importantConceptsPart1;

public class T001_ClassesandObjects {
	
	int model;
	static int year;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating object syntax
		//Classname objectreference = new Classname();
		T001_ClassesandObjects a = new T001_ClassesandObjects();//can create multiple objects for a single class
		T001_ClassesandObjects b= new T001_ClassesandObjects();
		T001_ClassesandObjects c = new T001_ClassesandObjects();
		
		//c1,c2,c3 are reference variables for an object.
		a.model = 215;
		year = 2015;
		
		b.model=222;
		b.year=2022;
		
		c.model=213;
		c.year=2013;
		
		System.out.println(a.year+" "+a.model);
		System.out.println(b.year+" "+b.model);
		System.out.println(c.year+" "+c.model);
		
		//Shifting object reference from one object to another object
		System.out.println("Shifting references");
		a=b;
		b=c;
		c=a;
		
		
		System.out.println(a.model);
		System.out.println(c.model);
		c.model=221;
		System.out.println(a.model);
		System.out.println(c.model);

	}

}
