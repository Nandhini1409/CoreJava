package importantConceptsPart1;

public class T007_CallbyValandCallbyRef {
	int p;
	int q;

	public static void main(String[] args) {
		
		T007_CallbyValandCallbyRef obj = new T007_CallbyValandCallbyRef();
		int x=40;
		int y = 60;
		obj.sum(x, y);//call by value or copying the value of parameters OR pass by value
		//obj.sum(12, 24)
		System.out.println(obj.sum(x, y));	
		obj.p = 40;
		obj.q = 60;
		
		obj.swap(obj);//call by reference
		System.out.println(obj.p);
		System.out.println(obj.q);

	}
	
	public int sum(int a,int b) {
		int c=a+b;
		return c;
	}

	
	public void swap(T007_CallbyValandCallbyRef t) {//passing the reference of class
		
		int temp;
		temp = t.p;//temp 40
		t.p=t.q;//t.q=50
		t.q=temp;//t.q = 50
		
		
	}
}
