package BasicConcepts;

public class T007_TwoDimensionalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[][] x=new String[3][5];
		System.out.println(x.length);//total no of rows
		System.out.println(x[0].length); //total no of columns
		//first row
		x[0][0]="A";
		x[0][1]="B";
		x[0][2]="C";
		x[0][3]="D";
		x[0][4]="E";
		//second row
		x[1][0]="A1";
		x[1][1]="B1";
		x[1][2]="C1";
		x[1][3]="D1";
		x[1][4]="E1";
		//third row
		x[2][0]="A2";
		x[2][1]="B2";
		x[2][2]="C2";
		x[2][3]="D2";
		x[2][4]="E2";
		
		for(int i=0;i<x.length;i++) {
			for(int j=0;j<x[0].length;j++) {
				System.out.print(x[i][j]+" ");
			}
			
			
			System.out.println();
		}
		//another examplen to declare two dimensional array
		int arr[][] = {{1,2,3},{4,5,6},{7,8,9}};
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		
		
		}
		
	}

}
