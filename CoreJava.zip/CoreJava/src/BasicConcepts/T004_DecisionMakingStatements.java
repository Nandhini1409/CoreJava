package BasicConcepts;

public class T004_DecisionMakingStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 170;
		int b = 150;
		int c = 100;
		
		//if, ifelse, nested if, if-else-if ladder
		if(a>b && a>c) {
		System.out.println(a);
			 if(b<c) {
				System.out.println(b);
			}else {
				System.out.println(c);
			}
	}
		
		//Switch Statement
		switch(b) {
		case 170:
			System.out.println(a);
			break;
		case 150:
			System.out.println(b);
			
		case 100:
			System.out.println(c);
			
		case 300:
			System.out.println(a);
			
		default:
			System.out.println("default");	
		
		}
		

	}

}
