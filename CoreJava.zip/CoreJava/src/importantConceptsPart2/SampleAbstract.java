package importantConceptsPart2;

public abstract class SampleAbstract {
	
	SampleAbstract(){
		
	}
	
	final String method2() {
		String s ="We";
		return s;
	}
	
	static void methodre() {
		
	};
	
	private int method3() {
		int i =90;
		return i;
	}
	//public is not mandatory and access specifier can be specified after the abstract keyword
	public abstract void noimplement();
	
	public abstract int noimplement1();
	
	public String implement(){
		String S ="Yes";
		System.out.println(S);
		return S;
	}

}
