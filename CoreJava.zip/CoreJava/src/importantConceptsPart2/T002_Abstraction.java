package importantConceptsPart2;

public class T002_Abstraction extends SampleAbstract{

	public static void main(String[] args) {

		T002_Abstraction ab = new T002_Abstraction();
		
		ab.implement();
		ab.noimplement();
		System.out.println(ab.noimplement1());
		

	}

	@Override
	public void noimplement() {
		System.out.println("Method of Abstract class extends in child class");
		
	}

	@Override
	public int noimplement1() {
		int a = 20;
		int b = 100;
		int c=a*b;
		//System.out.println(c);
		return c;
	}

}
