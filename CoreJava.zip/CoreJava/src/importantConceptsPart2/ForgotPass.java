package importantConceptsPart2;

public class ForgotPass extends Login {
	//forgot password
	
	public void name() {
		System.out.println("name in forgot password");
	}
	
	public void verify() {
		System.out.println("verify in forgot password");
	}
	
	public void clickSubmit() {
		System.out.println("submit in forgot password");
		
	}
	

}
