package importantConceptsPart2;

public class T001_Inheritance {
	
	public static void main(String[] args) {
		
		//Single Inheritance
		ForgotPass fp=new ForgotPass();
		fp.username();
		fp.clickSubmit(); //priority to child class
		System.out.println();
		
		//Multi-level Inheritance
		Homepage hp=new Homepage();
//		hp.username();
//		hp.verify();
//		hp.clickSubmit();
//		
		//Hieriarchial inheritance
		fp.username();
		fp.verify();
		
		hp.clickSubmit();
		hp.username();
		
		
	}
		
}
		