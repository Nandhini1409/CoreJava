package importantConceptsPart2;

public class Login {
	//login window
	
	public void username() {
		System.out.println("username in Login page");
	}

	public void password() {
		System.out.println("password in Login page");
		
	}
	
	public void clickSubmit() {
		System.out.println("Submit in Login page");
		
	}
}
