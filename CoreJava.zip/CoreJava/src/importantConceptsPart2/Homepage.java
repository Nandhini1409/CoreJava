package importantConceptsPart2;

public class Homepage extends ForgotPass{
	
	public void logo() {
		System.out.println("logo in home page");
	}

	public void Homebtn() {
		System.out.println("Home button in home page");
	}
	
	public void clickSubmit() {
		System.out.println("Submit in Home page");
	}
}
